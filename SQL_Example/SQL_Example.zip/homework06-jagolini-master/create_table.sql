-- write your table creation sql here!
CREATE TABLE shipping(id SERIAL PRIMARY KEY, cutomer_care_calls INTEGER, customer_rating INTEGER, prior_purchases INTEGER, discount_offered INTEGER, weight_in_gms INTEGER, warehouse_block VARCHAR(1), mode_of_shipment VARCHAR(6), product_importance VARCHAR(6), gender VARCHAR(1), class INTEGER);
