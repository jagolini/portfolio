-- write your queries underneath each number:
 
-- 1. the total number of rows in the database
SELECT COUNT(*) FROM shipping;
-- 2. show the first 15 rows, but only display 3 columns (your choice)
SELECT cutomer_care_calls, prior_purchases, product_importance FROM shipping LIMIT 15;
-- 3. do the same as above, but chose a column to sort on, and sort in descending order
SELECT * FROM shipping ORDER BY prior_purchases DESC LIMIT 15;
-- 4. add a new column without a default value
ALTER TABLE shipping ADD COLUMN order_date DATE;
-- 5. set the value of that new column
UPDATE shipping SET order_date = '2023-03-29' WHERE id = 1;
-- 6. show only the unique (non duplicates) of a column of your choice
SELECT DISTINCT gender FROM shipping;
-- 7.group rows together by a column value (your choice) and use an aggregate function to calculate something about that group 
SELECT product_importance, COUNT(*) FROM shipping GROUP BY product_importance;
-- 8. now, using the same grouping query or creating another one, find a way to filter the query results based on the values for the groups 
SELECT gender, AVG(weight_in_gms) FROM shipping GROUP BY gender;

 -- 9.Show the product_importance column and the count of all members of each group, but only for groups with a count greater than 100
SELECT product_importance, COUNT(*) FROM shipping GROUP BY product_importance HAVING COUNT(*) > 100;
-- 10. Show the mode_of_shipment column and the maximum customer_rating of the members of each group 
SELECT mode_of_shipment, MAX(customer_rating) FROM shipping GROUP BY mode_of_shipment;
--11. Show the product_importance column and the average prior_purchases of the members of each group, but only for groups where the average prior_purchases is greater than 2
SELECT product_importance, AVG(prior_purchases) FROM shipping GROUP BY product_importance HAVING AVG(prior_purchases) > 2;
--12. Show the warehouse_block column and the maximum discount_offered of the members of each group, but only for groups where the maximum discount_offered is greater than 50
SELECT warehouse_block, MAX(discount_offered) FROM shipping GROUP BY warehouse_block HAVING MAX(discount_offered) > 50;


