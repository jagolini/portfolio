-- write your COPY statement to import a csv here
COPY shipping(cutomer_care_calls , customer_rating , prior_purchases , discount_offered , weight_in_gms , warehouse_block , mode_of_shipment , product_importance, gender, class) FROM 'C:\Users\jagol\Documents\GitHub\homework04-jagolini\data\raw\shipping_ecommerce.csv' DELIMITER ',' CSV HEADER;
