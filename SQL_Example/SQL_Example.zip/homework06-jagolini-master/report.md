# Overview
Name / Title: Shipping E Commerce
Link to Data: https://www.kaggle.com/datasets/ulrikthygepedersen/shipping-ecommerce
Source / Origin:
Author or Creator: ULRIK THYGE PEDERSEN
Publication Date: Feb 1 2023
Publisher: Kaggle
Version or Data Accessed: Accessed Feb 16 2023
License: https://creativecommons.org/licenses/by/4.0/

Format: CSV
Size: 82KB
Number of Records: 10,998

Columns:
Customer_care_calls: INTEGER
Customer_rating: INTEGER
Prior_purchases: INTEGER
Discount_offered: INTEGER
Weight_in_gms: INTEGER
Warehouse_block: TEXT
Mode_of_Shipment: TEXT
Product_importance: TEXT
Gender: TEXT
Class: INTEGER


# Table Design
I chose a serial primary key as no columns offer a unique identifier. Null values do not need to be handled as there are no Null values in my data set. I used the INTEGER data type for my numbers and VARCHAR(longest size of cell in col) for strings. 

# Import
There were no errors importing 10,998 rows. 

# Database Information
homework06=# \l
                                                                 List of databases
    Name    |  Owner   | Encoding |          Collate           |           Ctype            | ICU Locale | Locale Provider |   Access privileges
------------+----------+----------+----------------------------+----------------------------+------------+-----------------+-----------------------
 homework06 | postgres | UTF8     | English_United States.1252 | English_United States.1252 |            | libc            |
 postgres   | postgres | UTF8     | English_United States.1252 | English_United States.1252 |            | libc            |
 template0  | postgres | UTF8     | English_United States.1252 | English_United States.1252 |            | libc            | =c/postgres          +
            |          |          |                            |                            |            |                 | postgres=CTc/postgres
 template1  | postgres | UTF8     | English_United States.1252 | English_United States.1252 |            | libc            | =c/postgres          +
            |          |          |                            |                            |            |                 | postgres=CTc/postgres
(4 rows)


homework06=# \dt
          List of relations
 Schema |   Name   | Type  |  Owner
--------+----------+-------+----------
 public | shipping | table | postgres
(1 row)


homework06=# \d shipping
                                         Table "public.shipping"
       Column       |         Type         | Collation | Nullable |               Default
--------------------+----------------------+-----------+----------+--------------------------------------
 id                 | integer              |           | not null | nextval('shipping_id_seq'::regclass)
 cutomer_care_calls | integer              |           |          |
 customer_rating    | integer              |           |          |
 prior_purchases    | integer              |           |          |
 discount_offered   | integer              |           |          |
 weight_in_gms      | integer              |           |          |
 warehouse_block    | character varying(1) |           |          |
 mode_of_shipment   | character varying(6) |           |          |
 product_importance | character varying(6) |           |          |
 gender             | character varying(1) |           |          |
 class              | integer              |           |          |
Indexes:
    "shipping_pkey" PRIMARY KEY, btree (id)


# Query Results
"""
 SELECT COUNT(*) FROM shipping;
 count
-------
 10998
(1 row)
"""
"""
SELECT cutomer_care_calls, prior_purchases, product_importance FROM shipping LIMIT 15;
 cutomer_care_calls | prior_purchases | product_importance
--------------------+-----------------+--------------------
                  5 |               2 | medium
                  4 |               2 | medium
                  3 |               2 | medium
                  3 |               2 | medium
                  7 |               4 | medium
                  6 |               2 | low
                  4 |               5 | low
                  4 |               3 | low
                  6 |               5 | low
                  4 |               2 | low
                  5 |               5 | medium
                  3 |               6 | low
                  6 |               4 | low
                  6 |               6 | medium
                  3 |               2 | medium
(15 rows)
"""
 SELECT * FROM shipping ORDER BY prior_purchases DESC LIMIT 15;
 id  | cutomer_care_calls | customer_rating | prior_purchases | discount_offered | weight_in_gms | warehouse_block | mode_of_shipment | product_importance | gender | class
-----+--------------------+-----------------+-----------------+------------------+---------------+-----------------+------------------+--------------------+--------+-------
 843 |                  4 |               4 |              10 |                3 |          4152 | D               | Road             | low                | F      |     1
 965 |                  3 |               2 |              10 |                7 |          5305 | F               | Ship             | high               | F      |     0
 693 |                  4 |               3 |              10 |                8 |          4337 | A               | Ship             | medium             | M      |     0
 813 |                  2 |               3 |              10 |                1 |          5632 | B               | Ship             | high               | F      |     0
 865 |                  4 |               5 |              10 |                9 |          5085 | B               | Ship             | medium             | M      |     1
 902 |                  3 |               5 |              10 |               32 |          2931 | A               | Ship             | medium             | M      |     1
 691 |                  3 |               2 |              10 |               28 |          1940 | A               | Ship             | high               | F      |     1
 309 |                  3 |               3 |              10 |                7 |          4273 | B               | Ship             | low                | F      |     1
 712 |                  4 |               4 |              10 |                3 |          4202 | C               | Ship             | low                | M      |     0
 784 |                  3 |               5 |              10 |                1 |          4929 | A               | Ship             | high               | F      |     1
 652 |                  3 |               4 |              10 |                5 |          5479 | F               | Ship             | low                | M      |     0
 358 |                  3 |               1 |              10 |                4 |          4496 | C               | Ship             | low                | F      |     1
 425 |                  5 |               4 |              10 |               34 |          2960 | B               | Ship             | medium             | F      |     1
 649 |                  4 |               3 |              10 |                7 |          5317 | F               | Ship             | high               | M      |     0
 998 |                  4 |               3 |              10 |               34 |          3935 | B               | Road             | low                | M      |     1
(15 rows)
"""


"""
ALTER TABLE shipping ADD COLUMN order_date DATE;
ALTER TABLE
"""

"""
UPDATE shipping SET order_date = '2023-03-29' WHERE id = 1;
UPDATE 1
"""


"""
SELECT DISTINCT gender FROM shipping;
 gender
--------
 M
 F
(2 rows)

"""

"""
SELECT product_importance, COUNT(*) FROM shipping GROUP BY product_importance;
 product_importance | count
--------------------+-------
 medium             |  4754
 high               |   948
 low                |  5296
(3 rows)

"""

"""
SELECT gender, AVG(weight_in_gms) FROM shipping GROUP BY gender;
 gender |          avg
--------+-----------------------
 M      | 3639.9077741107444078
 F      | 3627.9372294372294372
(2 rows)
"""


"""
 -- 9.Show the product_importance column and the count of all members of each group, but only for groups with a count greater than 100
SELECT product_importance, COUNT(*) FROM shipping GROUP BY product_importance HAVING COUNT(*) > 100;
 product_importance | count
--------------------+-------
 medium             |  4754
 high               |   948
 low                |  5296
(3 rows)

"""

"""
-- 10. Show the mode_of_shipment column and the maximum customer_rating of the members of each group 
SELECT mode_of_shipment, MAX(customer_rating) FROM shipping GROUP BY mode_of_shipment;
 mode_of_shipment | max
------------------+-----
 Flight           |   5
 Ship             |   5
 Road             |   5
(3 rows)
"""



"""
--11. Show the product_importance column and the average prior_purchases of the members of each group, but only for groups where the average prior_purchases is greater than 2
SELECT product_importance, AVG(prior_purchases) FROM shipping GROUP BY product_importance HAVING AVG(prior_purchases) > 2;
 product_importance |        avg
--------------------+--------------------
 medium             | 3.5936053849389987
 high               | 3.6571729957805907
 low                | 3.5281344410876133
(3 rows)
"""

"""
--12. Show the warehouse_block column and the maximum discount_offered of the members of each group, but only for groups where the maximum discount_offered is greater than 50
 warehouse_block, MAX(discount_offered) FROM shipping GROUP BY warehouse_block HAVING MAX(discount_offered) > 50;
 warehouse_block | max
-----------------+-----
 F               |  65
 D               |  65
 A               |  65
 C               |  65
 B               |  65
(5 rows)
"""


